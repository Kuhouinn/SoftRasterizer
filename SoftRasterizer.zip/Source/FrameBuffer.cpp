#include "FrameBuffer.h"
#include "Vector4.h"

FrameBuffer::FrameBuffer(unsigned int widthVal /*= 1920*/, unsigned int heightVal /*= 1080*/) :width(widthVal), height(heightVal)
{
	//colorBuffer.resize(widthVal * heightVal * 4);
	colorBuffer.resize(widthVal * heightVal);
	depthBuffer.resize(widthVal * heightVal);
}

void FrameBuffer::WritePixelColor(unsigned int x, unsigned int y, const Vector4& color)
{
	if (x >= width || y >= height || x < 0 || y < 0)
	{
		return;
	}

	//�д��Ľ�
	auto r = unsigned char(color.x * 255);
	auto g = unsigned char(color.y * 255);
	auto b = unsigned char(color.z * 255);
	auto a = unsigned char(color.w * 255);

// 	auto index = (y * width + x) * 4;
// 	colorBuffer[index] = r;
// 	colorBuffer[index + 1] = g;
// 	colorBuffer[index + 2] = b;
// 	colorBuffer[index + 3] = a;

	auto index = (y * width + x);
	unsigned int val = 0;
	val = val | a;
	val = val << 8 | r;
	val = val << 8 | g;
	val = val << 8 | b;

	colorBuffer[index] = val;
}

void FrameBuffer::WriteDepth(unsigned int x, unsigned int y, float depth)
{
	if (x >= width || y >= height || x < 0 || y < 0)
	{
		return;
	}

	auto index = y * width + x;
	depthBuffer[index] = depth;
}

void FrameBuffer::Clear(const Vector4& clearColor)
{
// 	auto r = unsigned char(clearColor.x * 255);
// 	auto g = unsigned char(clearColor.y * 255);
// 	auto b = unsigned char(clearColor.z * 255);
// 	auto a = unsigned char(clearColor.w * 255);
// 	auto data = colorBuffer.data();
// 	auto depthData = depthBuffer.data();
// 	for (auto y = 0; y < height; y++)
// 	{
// 		for (auto x = 0; x < width; x++)
// 		{
// 			auto index = (y * width + x) * 4;
// 			*(data + index) = r;
// 			*(data + index + 1) = g;
// 			*(data + index + 2) = b;
// 			*(data + index + 3) = a;
// 
// 			*(depthData + y * width + x) = 1.0f;
// 		}
// 	}

	auto r = unsigned char(clearColor.x * 255);
	auto g = unsigned char(clearColor.y * 255);
	auto b = unsigned char(clearColor.z * 255);
	auto a = unsigned char(clearColor.w * 255);

	unsigned int val = 0;
	val = val | a;
	val = val << 8 | r;
	val = val << 8 | g;
	val = val << 8 | b;

	auto data = colorBuffer.data();
	auto depthData = depthBuffer.data();

//  	for (auto y = 0; y < height; y++)
// 	{
// 		for (auto x = 0; x < width; x++)
// 		{
// 			long index = y * width + x;
// 			colorBuffer[index] = val;
// 			depthBuffer[index] = 1.0f;
// 		}
// 	}

 	colorBuffer.assign(width * height, val);
 	depthBuffer.assign(width * height, 1.0f);

	int aasd = 0;
}

float FrameBuffer::ReadDepth(int x, int y) const
{
	if (x < 0 || x >= width || y < 0 || y >= height)
	{
		return 0.0f;
	}

	return depthBuffer[width * y + x];
}
